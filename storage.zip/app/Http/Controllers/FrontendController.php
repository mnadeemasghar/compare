<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\item;
use App\Models\attribute;
use App\Models\contactus;
use App\Models\posts;
use App\Models\price;
use App\Models\sub;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class FrontendController extends Controller
{
    //
    public function url_detail(Request $request){
        $validator = Validator::make(
            $request->all(),[
            'url' => 'required|string|url',
        ]);
        if ($validator->fails()) {
            $error_messages = implode(',', $validator->messages()->all());
            $response_array = array('status' => false,  'message' => $error_messages);
            return response()->json(
                $response_array
            );
        }
        else{
            $data = DB::table('items-prices')->where('url', $request->url)->get();
            $name = DB::table('items-prices')->distinct('name')->where('url', $request->url)->value('name');
        return view('url_detail')->with('data',$data)->with('name', $name)->with('url',$request->url);
        }
    }
    public function submail(Request $request){
        if(sub::where('email',$request->submail)->get()->count()>0){
            return redirect()->back()->with('message',"You are already subscribed");
        }
        $sub = new sub;
        $sub->email = $request->submail;
        $sub->active = 1;

        if($sub->save()){
            return redirect()->back()->with('message',"Subscription Successful");
        }
        else{
            return redirect()->back()->with('message',"Something Went wrong, Please try again.");
        }
    }
    public function aboutus(){
        return view('frontend.aboutus');
    }
    public function welcome(){
        return view('welcome');
    }
    
    public function search(Request $request){
        if(!isset($request->search)){
            return view('welcome');
        }
        $validator = Validator::make(
            $request->all(),[
            'search' => 'required|string',
        ]);
        if ($validator->fails()) {
            $error_messages = implode(',', $validator->messages()->all());
            $response_array = array('status' => false,  'message' => $error_messages);
            return response()->json(
                $response_array
            );
        }
        else{
        $searchitems = DB::table('items-prices')
                        ->select([
                            'items-prices.name',
                            'items-prices.url as count_url',
                            DB::raw('(SELECT count(*) FROM `items-prices` WHERE `items-prices`.`url` = `count_url`) as count'),
                            DB::raw('(SELECT max(created_at) FROM `items-prices` WHERE `items-prices`.`url` = `count_url`) as latest_date'),
                            DB::raw('(SELECT `price` FROM `items-prices` WHERE `items-prices`.`url` = `count_url` ORDER BY `created_at` DESC LIMIT 1) as latest_price'),
                        ])
                        ->distinct('items-prices.url')
                        ->where('items-prices.name','like','%'.$request->search.'%')->paginate(5);
        return view('welcome')
            ->with('searchitems', $searchitems);
       
        }
    }

    public function update_item_id(){
        $items = item::all()->where('description','!=', "0");
        // dd($items);
        foreach($items as $item){
            // $attrs = Attribute::where('objectid',$item->description)->where('item_id', 0)->get();
            $attrs = Attribute::where('objectid',$item->description)->update(['item_id' => $item->id]);
            // foreach($attrs as $attr){
                //     $attr->item_id = $item->id;
                //     $attr->save();
                // }
            $item->description = "0";
            $item->save();
        }
        echo "done";
    }

    public function contactus(){
        return view('frontend.contactus');
    }
    
    public function submitContactUs(Request $request){
      
            $msg = new contactus;
            $msg->name = $request->name;
            $msg->email = $request->email;
            $msg->phone = $request->phone;
            $msg->message = $request->message;
    
            if($msg->save()){
                return redirect()->back()->with('message', "Thanks for your interest.");
            }
    }

    public function sitemap(){
        $data = item::join('items-prices', 'items-prices.item_id','items.id')->distinct()->get([
            'items.*'
        ]);
        return view('frontend.sitemap')->with('items',$data);
    }

    public function blog(){
        $posts = DB::table('posts')->orderByDesc('updated_at')->cursorPaginate(2);
        return view('frontend.blog')->with('posts',$posts);
    }
}
