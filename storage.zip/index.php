<?php
header('Location: ./public/');
?>